var recipes=[];
    var instructions=[];
    var ingredients=[];

    function addIngredients(){

        var rcpingredients=document.getElementById("rcpingredients");
        var lsting=document.getElementById("lstingredients");
        
        var ing=document.createElement("li");
        ing.textContent=rcpingredients.value;
        lsting.append(ing);
        

        ingredients.push(rcpingredients.value);

        rcpingredients.value="";
    }
    function addInstructions(){
        
        var rcpinstructions=document.getElementById("rcpinstructions");
        var lstins=document.getElementById("lstinstructions");
        
        var ins=document.createElement("li");
        ins.textContent=rcpinstructions.value;
        lstins.append(ins);
        let subarr=[];
       

        instructions.push(rcpinstructions.value);
        rcpinstructions.value="";
    }
    function saveRecipe(){
        var name=document.getElementById("recipename").value;
        var lstsvdrecipe=document.getElementById("lstsavedrecipe");
        if(instructions.length ==0 || ingredients.length ==0){
            alert("Please include instructions and ingredients!");
        }
        else{
            var subarray= [name,ingredients,instructions];
        var rcpes="<ul>";

        recipes.push(subarray);
        for(let x=0; x < recipes.length; x++){
            var arr=recipes[x];
            rcpes+='<li><button class="crisbutton" onclick="display('+x+')">'+arr[0]+'</button></li>';
        }
        rcpes+="</ul>";

        lstsvdrecipe.innerHTML=rcpes;
        document.getElementById("lstinstructions").innerHTML="";
        document.getElementById("lstingredients").innerHTML="";
        document.getElementById("recipename").value="";
        instructions=[];
        ingredients=[];
        }
    }

    function display(x){
        var ingredients=document.getElementById("rd_ingredients");
        var instructions=document.getElementById("rd_instructions");
        ingredients.innerHTML="";
        instructions.innerHTML="";


        var arr = recipes[x];
        var name=arr[0];
        var ing=arr[1];
        var ins=arr[2];

        document.getElementById("rd_name").innerHTML=name;
        for(let arr_ing of ing){
            var li_ing=document.createElement("li");
            li_ing.textContent=arr_ing;
            ingredients.appendChild(li_ing);
            console.log(li_ing);
        }
        for(let arr_ins of ins){
            let li_ins=document.createElement("li");
            li_ins.textContent=arr_ins;
            instructions.appendChild(li_ins);
        }

    }
