
var wordarray=[];

function addfunc(){
    var txt=document.getElementById("txt");
    if (txt.value != ""){
        wordarray.push(txt.value);
    }
    document.getElementById("txtwords").innerHTML= wordarray.join("<br>");
   txt.value="";
}
function sortfunc(){
    let sortedarray= wordarray.slice(0);
    sortedarray.sort();
    document.getElementById("txtwords").innerHTML= sortedarray.join("<br>");
}
function unsortfunc(){
    document.getElementById("txtwords").innerHTML= wordarray.join("<br>");
}
