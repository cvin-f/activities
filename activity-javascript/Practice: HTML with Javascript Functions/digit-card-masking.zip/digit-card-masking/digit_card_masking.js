
function isnumber(evt){
    var ch=String.fromCharCode(evt.which);

    if(!(/[0-9]/.test(ch))){
        evt.preventDefault();
    }
    else{

    }
}

function mask(){
    var numtxt=document.getElementById("number").value;
    document.getElementById("pnumbers").innerHTML="";
    if(numtxt.length < 16){
        alert("Card Number should be 16 digits long.")
    }
    else if (numtxt.length > 16){
        alert("Card Number should not exceed 16 digits.")
    }
    else{
        var msktext="";
        var count=0;
        var loop=0;
        for(let ch of numtxt){
            if(loop > 3 && loop < 12){
                ch="*";
            }
            if(count == 4)
            {
                msktext+=" "; 
                count=0;
            }
            msktext+=ch;  

            loop++;
            count++;
        }
        document.getElementById("pnumbers").innerHTML="Masked card number: " + msktext;
    }
}

function unmask(){
    var numtxt=document.getElementById("number").value;
    document.getElementById("pnumbers").innerHTML="";
    if(numtxt.length < 16){
        alert("Card Number should be 16 digits long.")
    }
    else if (numtxt.length > 16){
        alert("Card Number should not exceed 16 digits.")
    }
    else{
        var msktext="";
        var count=0;
        for(let ch of numtxt){ 
            if(count == 4)
            {
                msktext+=" "; 
                count=0;
            }
            msktext+=ch;  
            count++;
        }
        document.getElementById("pnumbers").innerHTML="Unmasked card number: " + msktext;
    }
}

